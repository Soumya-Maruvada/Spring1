package com.cg.labbook;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("employee.xml"); 
		Employee employee = (Employee) factory.getBean("employee");
		System.out.println("Employee Details");
		System.out.println("---------------------------");
		System.out.println("Employee Id : " + employee.getEmployeeId());
		System.out.println("Employee Name : " + employee.getEmployeeName());
		System.out.println("Employee Salary : " + employee.getEmployeeSal());
		System.out.println("Employee BU : " + employee.getBusinessUnit());
		System.out.println("Employee Age : " + employee.getAge());
	}

}
