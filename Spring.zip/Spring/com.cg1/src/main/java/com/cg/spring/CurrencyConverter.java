package com.cg.spring;


public interface CurrencyConverter {
	public double dollersToRupees(double dollars);
	
	
}
