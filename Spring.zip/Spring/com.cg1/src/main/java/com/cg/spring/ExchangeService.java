package com.cg.spring;


public interface ExchangeService {
	public double getExchangeRate();
}
