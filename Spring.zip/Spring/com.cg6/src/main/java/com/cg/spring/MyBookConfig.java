package com.cg.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBookConfig {
	
	//methods 
	
	@Bean
	public Author author(){
		return new Author("Aatish","Nagpur");
	}
	
	@Bean(initMethod = "setUp",destroyMethod = "cleanUp")
	public Book book(){
		Book book = new Book();
		book.setIsbn("abcd");
		book.setYear("2014");
		book.setAuthor(author());
		return book;
	}
}
