package com.cg.spring;
import javax.annotation.*;
public class Book {
	private String isbn;
	private String year;
	
	private Author author;
	// set get

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getYear() {
		return year;
	}
	
	public void setYear(String year) {
		this.year = year;
	}
	
	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}
	
	// methods
	
	@PostConstruct
	public void customInit() {
		System.out.println("This is customInit() from book");
	}
	
	@PreDestroy
	public void customDestroy() {
		System.out.println("This is customDestroy() from book");
	}
	
	private void setUp() {
		System.out.println("This is setUp() from book");
	}

	private void cleanUp() {
		System.out.println("This is cleanUp() from book");
	}
	// toString

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", year=" + year + ", author=" + author
				+ "]";
	}

	

}
