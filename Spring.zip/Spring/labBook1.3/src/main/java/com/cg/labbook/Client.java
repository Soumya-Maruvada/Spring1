package com.cg.labbook;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("sbu.xml"); 
		SBU sbu = (SBU) factory.getBean("sbu");
		//ArrayList<Employee> employee = (ArrayList<Employee>) factory.getBean("employee");
		//SBU sbu = (SBU) factory.getBean("sbu");
		System.out.println("sbu Details");
		System.out.println("---------------------------");
		System.out.println(sbu);
		System.out.println("Employee Details");
		System.out.println("---------------------------");
		//List<Employee> list = sbu.setEmpList(employee);
		System.out.println(sbu.getEmpList());
		//System.out.println(employee);
		
		//System.out.println("sub Details " + );
	}

}
