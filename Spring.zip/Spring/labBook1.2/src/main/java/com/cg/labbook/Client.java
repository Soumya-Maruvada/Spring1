package com.cg.labbook;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("employee.xml"); 
		Employee employee = (Employee) factory.getBean("employee");
		SBU sbu = (SBU) factory.getBean("sbu");
		System.out.println("Employee Details");
		System.out.println("---------------------------");
		employee.setBusinessUnit(sbu);	
		System.out.println(employee);
		SBU sbuBean = employee.getBusinessUnit();
		System.out.println("sub Details " + sbuBean);
	}

}
