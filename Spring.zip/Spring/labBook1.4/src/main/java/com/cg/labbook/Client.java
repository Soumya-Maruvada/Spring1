package com.cg.labbook;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("sbu.xml"); 
		Employee employee = (Employee) factory.getBean("employee.xml");
	}

}
