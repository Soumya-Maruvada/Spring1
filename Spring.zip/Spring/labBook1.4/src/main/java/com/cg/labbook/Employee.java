package com.cg.labbook;

public class Employee {
	private int employeeId;
	private String employeeName;
	private double employeeSal;
	private int employeeAge;

	
	//set get
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	public double getEmployeeSal() {
		return employeeSal;
	}
	public void setEmployeeSal(double employeeSal) {
		this.employeeSal = employeeSal;
	}
	public int getEmployeeAge() {
		return employeeAge;
	}
	public void setEmployeeAge(int employeeAge) {
		this.employeeAge = employeeAge;
	}
	
	//constructor
	
	public Employee(int employeeId, String employeeName, double employeeSal,
			int employeeAge) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeSal = employeeSal;
		this.employeeAge = employeeAge;
	}
	public Employee() {
		super();
	}
	// toString
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName="
				+ employeeName + ", employeeSal=" + employeeSal
				+ ", employeeAge=" + employeeAge + "]";
	}
	
	
}
