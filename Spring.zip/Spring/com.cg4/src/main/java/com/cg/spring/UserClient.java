package com.cg.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class UserClient {
	public static void main(String[] args) {
		ApplicationContext factory = new ClassPathXmlApplicationContext("user.xml");
		User user = (User) factory.getBean("userBean");
		System.out.println(user.getUserName());
		System.out.println(user.getPassWord());
	}
}
